package net.voidclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.voidclient.modules.CoordsModule;
import net.voidclient.modules.FpsModule;
import net.voidclient.modules.FullbrightModule;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("voidclient.json");

    private ModuleManager() {}

    public static void init() {
        MODULES.add(new FullbrightModule());
        MODULES.add(new FpsModule());
        MODULES.add(new CoordsModule());
        load();
    }

    public static void tick() {
        for (Module m : MODULES) {
            if (m.enabled) m.onTick();
        }
    }

    public static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        int y = 4;
        for (Module m : MODULES) {
            if (!m.enabled) continue;
            String text = m.hudText();
            if (text == null) continue;
            ctx.drawText(mc.textRenderer, text, 5, y, 0xFFFF3B3B, true);
            y += 11;
        }
    }

    public static void save() {
        try {
            Map<String, Boolean> map = new LinkedHashMap<>();
            for (Module m : MODULES) map.put(m.name, m.enabled);
            try (Writer w = Files.newBufferedWriter(FILE)) {
                GSON.toJson(map, w);
            }
        } catch (Exception ignored) {}
    }

    private static void load() {
        try {
            if (!Files.exists(FILE)) return;
            try (Reader r = Files.newBufferedReader(FILE)) {
                Map<String, Boolean> map = GSON.fromJson(r, new TypeToken<Map<String, Boolean>>() {}.getType());
                if (map == null) return;
                for (Module m : MODULES) {
                    Boolean b = map.get(m.name);
                    if (b != null) m.enabled = b;
                }
            }
        } catch (Exception ignored) {}
    }
}
