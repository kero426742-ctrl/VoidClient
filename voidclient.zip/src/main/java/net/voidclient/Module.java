package net.voidclient;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String description;
    public final String category;
    public boolean enabled;

    protected Module(String name, String description, String category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
        ModuleManager.save();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}

    /** HUD modules return the text to show, others return null. */
    public String hudText() { return null; }
}
