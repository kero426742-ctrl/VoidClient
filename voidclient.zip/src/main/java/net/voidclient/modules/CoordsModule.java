package net.voidclient.modules;

import net.voidclient.Module;

public class CoordsModule extends Module {
    public CoordsModule() {
        super("Coords", "Shows your position", "HUD");
    }

    @Override
    public String hudText() {
        if (mc.player == null) return null;
        return "XYZ: " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ();
    }
}
