package net.voidclient.modules;

import net.voidclient.Module;

public class FpsModule extends Module {
    public FpsModule() {
        super("FPS", "Shows your FPS", "HUD");
    }

    @Override
    public String hudText() {
        return "FPS: " + mc.getCurrentFps();
    }
}
