package net.voidclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ModuleScreen extends Screen {
    private static final int CW = 150, CH = 44, GAP = 8;
    private static final int RED = 0xFFE02020, DARK_RED = 0xFF5A1010;
    private final List<int[]> rects = new ArrayList<>();

    public ModuleScreen() {
        super(Text.literal("VoidClient"));
    }

    @Override
    protected void init() {
        rects.clear();
        int cols = Math.max(1, Math.min(4, (width - 40 + GAP) / (CW + GAP)));
        int totalW = cols * CW + (cols - 1) * GAP;
        int startX = (width - totalW) / 2;
        int startY = 62;
        for (int i = 0; i < ModuleManager.MODULES.size(); i++) {
            Module m = ModuleManager.MODULES.get(i);
            int x = startX + (i % cols) * (CW + GAP);
            int y = startY + (i / cols) * (CH + GAP);
            rects.add(new int[]{x, y});
            // invisible hit area; the card itself is drawn in render()
            ButtonWidget b = ButtonWidget.builder(Text.empty(), btn -> m.toggle())
                    .dimensions(x, y, CW, CH).build();
            b.setAlpha(0f);
            addDrawableChild(b);
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        ctx.fill(0, 0, width, 52, 0xE0120404);
        ctx.fill(0, 51, width, 52, RED);
        ctx.drawText(textRenderer, "VOID", 16, 14, RED, true);
        ctx.drawText(textRenderer, "CLIENT", 16 + textRenderer.getWidth("VOID") + 2, 14, 0xFFFFFFFF, true);
        ctx.drawText(textRenderer, "Modules  -  click a card to toggle", 16, 30, 0xFFAA7777, false);

        for (int i = 0; i < ModuleManager.MODULES.size(); i++) {
            Module m = ModuleManager.MODULES.get(i);
            int x = rects.get(i)[0], y = rects.get(i)[1];
            boolean hover = mouseX >= x && mouseX < x + CW && mouseY >= y && mouseY < y + CH;

            int border = m.enabled ? RED : DARK_RED;
            int inner = m.enabled ? (hover ? 0xFF3A1212 : 0xFF2A0C0C) : (hover ? 0xFF241010 : 0xFF160808);
            ctx.fill(x, y, x + CW, y + CH, border);
            ctx.fill(x + 1, y + 1, x + CW - 1, y + CH - 1, inner);

            ctx.drawText(textRenderer, m.name, x + 8, y + 8, 0xFFFFFFFF, true);
            ctx.drawText(textRenderer, m.category, x + 8, y + 21, 0xFF996666, false);
            ctx.drawText(textRenderer, m.enabled ? "ON" : "OFF", x + 8, y + 31,
                    m.enabled ? 0xFFFF4040 : 0xFF775555, true);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
